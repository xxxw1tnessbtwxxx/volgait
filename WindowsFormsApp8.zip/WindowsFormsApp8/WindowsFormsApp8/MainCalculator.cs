﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class MainCalculator : Form
    {

        DataTable dtShedule = new DataTable();

        public MainCalculator()
        {
            InitializeComponent();
            cb_paymenttype.SelectedIndex = 0;
        }


        // USELESS
        static void Initialize(List<ComboBox> boxes, int[] yearLimit)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           cb_betview.SelectedIndex = 0;
           cb_currency.SelectedIndex = 0;
           cb_lengthcheck.SelectedIndex = 0;
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lb_title_Click(object sender, EventArgs e)
        {

        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            CreditCalculations calculator = new CreditCalculations((double.Parse(tb_sum.Text)), double.Parse(tb_bet.Text), (int)(numericUpDown1.Value), (CalcType)cb_paymenttype.SelectedIndex);
            dtShedule = calculator.GetShedule();
            dgv_schedule.DataSource = dtShedule;

            dgv_schedule.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            for (int i = 1; i < dgv_schedule.Columns.Count; i++)
            {
                dgv_schedule.Columns[i].DefaultCellStyle.Format = String.Format("### ### ### ##0.#0");
                dgv_schedule.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                dgv_schedule.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            btn_exportToCsv.Enabled = true;
        }

        private void btn_exportToCsv_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "Экспорт графика платежей";
            save.Filter = "*.CSV-файл с разделителями |*.csv";
            if (save.ShowDialog() == DialogResult.OK)
                CreditCalculations.ExportDataToCSV(save.FileName, dtShedule, tb_sum.Text.ToString());
        }
    }
}
