﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{

    public enum CalcType { ANN, DIFF }

    class CreditCalculations
    {

        public static void ExportDataToCSV(string filename, DataTable dataTable, string creditAmount)
        {
            FileStream fs = null;
            StreamWriter sw = null;
            try
            {
                fs = new FileStream(filename, FileMode.Create, FileAccess.Write);
                sw = new StreamWriter(fs, Encoding.Default);
                sw.WriteLine(String.Join(";", dataTable.Columns[0].Caption, dataTable.Columns[1].Caption, dataTable.Columns[2].Caption, dataTable.Columns[3].Caption, dataTable.Columns[4].Caption));
                for (int i = 0; i < dataTable.Rows.Count; i++)
                    sw.WriteLine(String.Join(";", dataTable.Rows[i][0], dataTable.Rows[i][1], dataTable.Rows[i][2], dataTable.Rows[i][3], dataTable.Rows[i][4]));
                sw.WriteLine(String.Join(";", "Итого", creditAmount));
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                sw?.Close();
                fs?.Close();
            }
        }

        public CreditCalculations(double creditAmount, double creditRate, int creditPeriod, CalcType selectCalcType) 
        {
            CreditAmount = creditAmount;
            CreditRateYear = creditRate;
            CreditPeriod = creditPeriod;
            SelectedCalcType = selectCalcType;
        }


        private double _creditYear; // Переменная для годовой ставки
        private double _creditMonth; // Переменная для месячной ставки

        private string _summaryMonthlyPayment; // Для результата ежемесячного платежа
        private string _summaryCreditAmount; // Для результата итоговой суммы кредита
        private string _summaryOverPayment; // Для результата переплаты по кредиту

        #region Информация о годовой по кредиту в процентах
        public double CreditRateYear
        {
            get
            {
                return _creditYear * 100;
            }
            set
            {
                _creditYear = value / 100;
                _creditMonth = value / 100 / 12;
            }
        }
        #endregion

        public double CreditAmount { get; set; }
        public int CreditPeriod { get; private set; } // Срок кредита (месяцев)
        public CalcType SelectedCalcType { get; set; } // Вид платежа

        public DataTable GetShedule()
        {
            DataTable dtShedule = new DataTable();
            dtShedule.Columns.Add("Месяц", typeof(int));
            dtShedule.Columns.Add("Сумма платежа", typeof(double));
            dtShedule.Columns.Add("Платеж по основному долгу, руб.", typeof(double));
            dtShedule.Columns.Add("Платеж по процентам, руб.", typeof(double));
            dtShedule.Columns.Add("Остаток основного долга, руб.", typeof(double));

            DataRow dr;

            // АННУИТЕТНЫЙ ПЛАТЕЖ
            if (SelectedCalcType == CalcType.ANN)
            {
                double monthlyPayment = CreditAmount * (_creditMonth / (1 - Math.Pow(1 + _creditMonth, -CreditPeriod))); // Вычисление ежемесячного платежа
                double summaryCreditAmount = monthlyPayment * CreditPeriod; // Итоговая сумма кредита

                _summaryMonthlyPayment = monthlyPayment.ToString("N2"); // Для результатов
                _summaryCreditAmount = summaryCreditAmount.ToString("N2"); // Для результатов

                double tempCreditAmount = CreditAmount;
                double tempSummaryCreditAmount = summaryCreditAmount;
                double tempItogPlus = 0;

                for (int i = 1; i <= CreditPeriod; i++)
                {
                    dr = dtShedule.NewRow();
                    double percent = tempCreditAmount * _creditMonth;
                    tempCreditAmount -= monthlyPayment - percent;
                    dr[0] = i; 
                    dr[1] = monthlyPayment; 
                    dr[2] = monthlyPayment - percent; 
                    dr[3] = percent; 
                    dr[4] = tempCreditAmount;
                    tempSummaryCreditAmount -= monthlyPayment;
                    if (i == CreditPeriod) tempItogPlus = tempCreditAmount;
                    dtShedule.Rows.Add(dr);
                }

                _summaryOverPayment = (summaryCreditAmount - CreditAmount + tempItogPlus).ToString("N2"); // Для результатов
            }
            // ДИФФЕРЕНЦИРОВАННЫЙ ПЛАТЕЖ
            if (SelectedCalcType == CalcType.DIFF)
            {
                double mainPayment = CreditAmount / CreditPeriod;
                double summaryCreditAmount = 0;
                double summaryOverPayment = 0;
                double tempCreditAmount = CreditAmount;
                double itogPlus = 0;

                for (int i = 1; i <= CreditPeriod; i++)
                {
                    dr = dtShedule.NewRow();
                    double percent = tempCreditAmount * _creditMonth;
                    double monthlyPayment = mainPayment + percent;
                    summaryCreditAmount += monthlyPayment; 
                    summaryOverPayment += percent; 
                    tempCreditAmount -= mainPayment; 
                    dr[0] = i;
                    dr[1] = monthlyPayment; 
                    dr[2] = mainPayment;
                    dr[3] = percent; 
                    dr[4] = tempCreditAmount;
                    dtShedule.Rows.Add(dr);
                    if (i == 1) _summaryMonthlyPayment = monthlyPayment.ToString("N2") + "...";
                    if (i == CreditPeriod)
                    {
                        _summaryMonthlyPayment += monthlyPayment.ToString("N2");
                        itogPlus += tempCreditAmount;
                    }
                }

                _summaryCreditAmount = summaryCreditAmount.ToString("N2");
                _summaryOverPayment = (summaryOverPayment + itogPlus).ToString("N2");


            }

            return dtShedule;
        }


        public string GetSummaryOverPayment()
        {
            return _summaryOverPayment;
        }


        public string GetSummaryCreditAmount()
        {
            return _summaryCreditAmount;
        }


        public string GetMonthlyPayment()
        {
            return _summaryMonthlyPayment;
        }

        
        public static decimal GetCreditAmount(decimal costOfPurchase, decimal initialPayment)
        {
            return costOfPurchase - initialPayment;
        }

    }
}
