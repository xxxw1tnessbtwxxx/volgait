﻿namespace WindowsFormsApp8
{
    partial class MainCalculator
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainCalculator));
            this.lb_title = new System.Windows.Forms.Label();
            this.lb_desc = new System.Windows.Forms.Label();
            this.lb_creditsum = new System.Windows.Forms.Label();
            this.lb_length = new System.Windows.Forms.Label();
            this.lb_percentage = new System.Windows.Forms.Label();
            this.lb_bet = new System.Windows.Forms.Label();
            this.lb_view = new System.Windows.Forms.Label();
            this.tb_sum = new System.Windows.Forms.TextBox();
            this.tb_bet = new System.Windows.Forms.TextBox();
            this.tb_percentage = new System.Windows.Forms.TextBox();
            this.btn_calculate = new System.Windows.Forms.Button();
            this.cb_currency = new System.Windows.Forms.ComboBox();
            this.cb_lengthcheck = new System.Windows.Forms.ComboBox();
            this.cb_betview = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.cb_paymenttype = new System.Windows.Forms.ComboBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.dgv_schedule = new System.Windows.Forms.DataGridView();
            this.btn_exportToCsv = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_schedule)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_title
            // 
            resources.ApplyResources(this.lb_title, "lb_title");
            this.lb_title.Name = "lb_title";
            this.lb_title.Click += new System.EventHandler(this.lb_title_Click);
            // 
            // lb_desc
            // 
            resources.ApplyResources(this.lb_desc, "lb_desc");
            this.lb_desc.Name = "lb_desc";
            // 
            // lb_creditsum
            // 
            resources.ApplyResources(this.lb_creditsum, "lb_creditsum");
            this.lb_creditsum.Name = "lb_creditsum";
            // 
            // lb_length
            // 
            resources.ApplyResources(this.lb_length, "lb_length");
            this.lb_length.Name = "lb_length";
            // 
            // lb_percentage
            // 
            resources.ApplyResources(this.lb_percentage, "lb_percentage");
            this.lb_percentage.Name = "lb_percentage";
            // 
            // lb_bet
            // 
            resources.ApplyResources(this.lb_bet, "lb_bet");
            this.lb_bet.Name = "lb_bet";
            // 
            // lb_view
            // 
            resources.ApplyResources(this.lb_view, "lb_view");
            this.lb_view.Name = "lb_view";
            // 
            // tb_sum
            // 
            this.tb_sum.BackColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.tb_sum, "tb_sum");
            this.tb_sum.Name = "tb_sum";
            // 
            // tb_bet
            // 
            resources.ApplyResources(this.tb_bet, "tb_bet");
            this.tb_bet.Name = "tb_bet";
            // 
            // tb_percentage
            // 
            resources.ApplyResources(this.tb_percentage, "tb_percentage");
            this.tb_percentage.Name = "tb_percentage";
            // 
            // btn_calculate
            // 
            this.btn_calculate.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_calculate.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_calculate.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_calculate, "btn_calculate");
            this.btn_calculate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_calculate.Name = "btn_calculate";
            this.btn_calculate.UseVisualStyleBackColor = false;
            this.btn_calculate.Click += new System.EventHandler(this.btn_calculate_Click);
            // 
            // cb_currency
            // 
            resources.ApplyResources(this.cb_currency, "cb_currency");
            this.cb_currency.FormattingEnabled = true;
            this.cb_currency.Items.AddRange(new object[] {
            resources.GetString("cb_currency.Items")});
            this.cb_currency.Name = "cb_currency";
            // 
            // cb_lengthcheck
            // 
            resources.ApplyResources(this.cb_lengthcheck, "cb_lengthcheck");
            this.cb_lengthcheck.FormattingEnabled = true;
            this.cb_lengthcheck.Items.AddRange(new object[] {
            resources.GetString("cb_lengthcheck.Items"),
            resources.GetString("cb_lengthcheck.Items1")});
            this.cb_lengthcheck.Name = "cb_lengthcheck";
            // 
            // cb_betview
            // 
            resources.ApplyResources(this.cb_betview, "cb_betview");
            this.cb_betview.FormattingEnabled = true;
            this.cb_betview.Items.AddRange(new object[] {
            resources.GetString("cb_betview.Items")});
            this.cb_betview.Name = "cb_betview";
            // 
            // comboBox4
            // 
            resources.ApplyResources(this.comboBox4, "comboBox4");
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Name = "comboBox4";
            // 
            // cb_paymenttype
            // 
            resources.ApplyResources(this.cb_paymenttype, "cb_paymenttype");
            this.cb_paymenttype.FormattingEnabled = true;
            this.cb_paymenttype.Items.AddRange(new object[] {
            resources.GetString("cb_paymenttype.Items"),
            resources.GetString("cb_paymenttype.Items1")});
            this.cb_paymenttype.Name = "cb_paymenttype";
            // 
            // numericUpDown1
            // 
            resources.ApplyResources(this.numericUpDown1, "numericUpDown1");
            this.numericUpDown1.Name = "numericUpDown1";
            // 
            // dgv_schedule
            // 
            this.dgv_schedule.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_schedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dgv_schedule, "dgv_schedule");
            this.dgv_schedule.Name = "dgv_schedule";
            this.dgv_schedule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            // 
            // btn_exportToCsv
            // 
            this.btn_exportToCsv.BackColor = System.Drawing.SystemColors.ControlLight;
            resources.ApplyResources(this.btn_exportToCsv, "btn_exportToCsv");
            this.btn_exportToCsv.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_exportToCsv.FlatAppearance.BorderSize = 0;
            this.btn_exportToCsv.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_exportToCsv.Name = "btn_exportToCsv";
            this.btn_exportToCsv.UseVisualStyleBackColor = false;
            this.btn_exportToCsv.Click += new System.EventHandler(this.btn_exportToCsv_Click);
            // 
            // MainCalculator
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.btn_exportToCsv);
            this.Controls.Add(this.dgv_schedule);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.cb_paymenttype);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.cb_betview);
            this.Controls.Add(this.cb_lengthcheck);
            this.Controls.Add(this.cb_currency);
            this.Controls.Add(this.btn_calculate);
            this.Controls.Add(this.tb_percentage);
            this.Controls.Add(this.tb_bet);
            this.Controls.Add(this.tb_sum);
            this.Controls.Add(this.lb_view);
            this.Controls.Add(this.lb_percentage);
            this.Controls.Add(this.lb_bet);
            this.Controls.Add(this.lb_length);
            this.Controls.Add(this.lb_creditsum);
            this.Controls.Add(this.lb_desc);
            this.Controls.Add(this.lb_title);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainCalculator";
            this.TransparencyKey = System.Drawing.Color.Red;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_schedule)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_title;
        private System.Windows.Forms.Label lb_desc;
        private System.Windows.Forms.Label lb_creditsum;
        private System.Windows.Forms.Label lb_length;
        private System.Windows.Forms.Label lb_percentage;
        private System.Windows.Forms.Label lb_bet;
        private System.Windows.Forms.Label lb_view;
        private System.Windows.Forms.TextBox tb_sum;
        private System.Windows.Forms.TextBox tb_bet;
        private System.Windows.Forms.TextBox tb_percentage;
        private System.Windows.Forms.Button btn_calculate;
        private System.Windows.Forms.ComboBox cb_currency;
        private System.Windows.Forms.ComboBox cb_lengthcheck;
        private System.Windows.Forms.ComboBox cb_betview;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox cb_paymenttype;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.DataGridView dgv_schedule;
        private System.Windows.Forms.Button btn_exportToCsv;
    }
}

